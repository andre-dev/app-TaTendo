<?php
$data = json_decode(file_get_contents("php://input"));
$filter = filter_input(INPUT_SERVER,'REQUEST_METHOD');
require ('./_app/Config.php'); 
         
if($filter === 'POST'){
    switch ($data->parametros) {
      //============================================ cadastro =============================================================
       case "cadastro":
       $Dados = [];

            $cadastra = new Create();
            $cadastra->ExeCreate('', $Dados);
            //Leitura no Banco
            $read = new Read;
            $read->ExeRead('');
            echo json_encode($read->getResult());
      break;
      //============================================= Leitura =============================================================
      case "leitura":
            $read = new Read;
            $read->ExeRead('tabela',"");
            //$read->FullRead("");

            echo json_encode($read->getResult());  
       break;
       
      //============================================= atualizar ===========================================
       case "atualizar":
            $Dados = [];
            $update = new Update;
            $update->ExeUpdate('tabela', $Dados, "WHERE =:cod", "cod={}");
            echo json_encode($update->getResult());
            
      break;

      //============================================= Delete ===============================================
       case "deletar":
            $delete = new Delete;
            $delete->ExeDelete('tabela', "WHERE  = :cod", "cod={}");
            $read = new Read;
            $read->ExeRead('tabela',"WHERE cod =''");
             echo json_encode($read->getResult()); 
       break;
       default:   
       break;
       }    
}else{
   
            $read = new Read;
            $read->ExeRead('cadastro');
            echo json_encode($read->getResult()); 
}
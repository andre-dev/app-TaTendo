'use strict';
angular.module('app.controllers').value('ConfigUrl', {
BaseUrl:"http:///api.php"
});